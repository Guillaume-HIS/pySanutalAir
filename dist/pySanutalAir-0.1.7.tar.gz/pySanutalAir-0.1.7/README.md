# pySanutalAir
Python3 library to control home ventilation systems from Sanutal, AIR 2/3/4/5

## Intended use
Intended to be used through Home Assistant